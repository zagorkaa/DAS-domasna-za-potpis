import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TemperatureMonitor {
    public static void main(String[] args) {
        while (true) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader("temperature.txt"));
                String[] temperatures = reader.readLine().trim().split(" ");
                int total = 0;
                for (String temperature : temperatures) {
                    total += Integer.parseInt(temperature);
                }
                int average = total / temperatures.length;

                String level;
                if (average >= 5 && average <= 19) {
                    level = "Low";
                } else if (average >= 20 && average <= 35) {
                    level = "Medium";
                } else {
                    level = "High";
                }

                FileWriter writer = new FileWriter("temperaturelevel.txt");
                writer.write(level + " ");
                writer.close();
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Sleep for 60 seconds
            try {
                Thread.sleep(60000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
