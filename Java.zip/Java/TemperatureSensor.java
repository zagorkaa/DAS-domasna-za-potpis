import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class TemperatureSensor {
    public static void main(String[] args) {
        try {
            FileWriter writer = new FileWriter("temperature.txt");
            Random random = new Random();
            for (int i = 0; i < 5; i++) {
                int temperature = random.nextInt(46) + 5;
                writer.write(temperature + " ");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
